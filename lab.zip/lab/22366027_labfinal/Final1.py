my_file = open('input1.txt', 'r')
output_file = open('output1.txt', 'w')

n, m = map(int, my_file.readline().split())        
edges = []
for i in range(m):
    x, y = map(int, my_file.readline().split())
    edges.append([x, y])
graph = dict()
for i in range(n):
    lst = []
    for j in range(m):
        if edges[j][0] == i+1:
            lst.append([edges[j][0], edges[j][1]])
        graph[i+1] = lst

output_file.write(str(graph))

output_file.close()