my_file = open('input.txt', 'r')
output_file = open('output.txt', 'w')
c = [[0 for i in range(100)] for j in range(100)]
t = [[None for i in range(100)] for j in range(100)]

def LCS(X, Y):
    m = len(X) 
    n = len(Y) 
    for i in range(m):
      for j in range (n):
        if X[i] == Y[j]:
           c[i][j] = c[i-1][j-1]+1

        elif c[i-1][j] >= c[i][j-1]:
           c[i][j] = c[i-1][j]

        else:
           c[i][j] = c[i][j-1]

n, m = map(int, my_file.readline().split())        
edges = []
for i in range(m):
    x, y = map(int, my_file.readline().split())
    edges.append([x, y])
graph = dict()
for i in range(n):
    lst = []
    for j in range(m):
        if edges[j][0] == i+1:
            lst.append([edges[j][0], edges[j][1]])
        graph[i+1] = lst       
LCS(X, Y)

output_file.write(c[len(X)-1][len(Y)-1])