def isPalindrome(word):
    if word is None:
        return "not a palindrome"
    n = len(word)
    i = 0
    while i<(n//2):
        if word[i]!= word[n-i-1]:
            return "not a palindrome"
        i+=1
    return "palindrome"



f = open("input.txt","r")
output = open("output.txt","w")
record = open("record.txt","w")
f = f.read()
lines = f.split("\n")
OddParity = 0
EvenParity = 0
NoParity = 0
total = len(lines)
TotalPalindrome = 0
TotalNonPalindrome = 0

for i in lines:
    info = i.split(" ")

    number = eval(info[0])
    if isinstance(number, int):
        if number % 2 == 0:
            EvenParity += 1
            number_out = f"{number} has even parity"
        else:
            OddParity += 1
            number_out = f"{number} has odd  parity"
    else:
        NoParity += 1
        number_out = f"{number} cannot have parity"

    text = info[1]
    text_out = isPalindrome(text)
    if text_out == "palindrome":
        TotalPalindrome += 1
    else:
        TotalNonPalindrome += 1

    print(f"{number_out} and {text} {text_out}")
    output.write(f"{number_out} and {text} {text_out}")
    output.write("\n")

output.close()

record.write(f"Percentage of odd parity: {OddParity*100//total}%")
record.write("\n")
record.write(f"Percentage of even parity: {EvenParity*100//total}%")
record.write("\n")
record.write(f"Percentage of parity: {NoParity*100//total}%")
record.write("\n")
record.write(f"Percentage of palindorme: {TotalPalindrome*100//total}%")
record.write("\n")
record.write(f"Percentage of palindorme: {TotalNonPalindrome*100//total}%")
record.write("\n")

record.close()




