def Multiply_matrix(a,b):
    n = len(a)
    c = []
    for row in range(n):
        row = []
        for col in range(n):
            row.append(0)
        c.append(row)

    for i in range(n):
        for j in range(n):
            for k in range(n):
                c[i][j] += a[i][k]*b[k][j]

    return c


inp = open("input4.txt", "r")
out= open("output4.txt", "w")
inp = inp.read()
text= inp.split()
n = int(text[0])
a = []
b = []
value = []
i = 1
while (i<len(text)):
    row = []
    for j in range(n):
        row.append(int(text[i]))
        i += 1
    value.append(row)

for i in range(len(value)):
    if i<len(value)//2:
        a.append(value[i])
    else:
        b.append(value[i])

elements = Multiply_matrix(a,b)
for i in elements:
    for j in i:
        out.write(f"{j} ")
    out.write("\n")

out.close()